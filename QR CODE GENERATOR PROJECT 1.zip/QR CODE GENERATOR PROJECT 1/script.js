// script.js
document.getElementById('signUp').addEventListener('click', () => {
    document.getElementById('login-container').classList.add('right-panel-active');
});

document.getElementById('signIn').addEventListener('click', () => {
    document.getElementById('login-container').classList.remove('right-panel-active');
});

document.getElementById('signup-form').addEventListener('submit', function (e) {
    e.preventDefault();
    alert('Sign Up Successful! Redirecting to QR Code Generator.');
    document.getElementById('login-container').style.display = 'none';
    document.getElementById('qr-container').style.display = 'flex';
});

document.getElementById('login-form').addEventListener('submit', function (e) {
    e.preventDefault();
    alert('Login Successful! Redirecting to QR Code Generator.');
    document.getElementById('login-container').style.display = 'none';
    document.getElementById('qr-container').style.display = 'flex';
});

document.getElementById('generate').addEventListener('click', function () {
    const text = document.getElementById('text').value;
    const qrCodeContainer = document.getElementById('qr-code');
    qrCodeContainer.innerHTML = '';

    if (text.trim() === '') {
        alert('Please enter some text or URL!');
        return;
    }

    const qrCode = document.createElement('img');
    const apiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(text)}`;
    qrCode.src = apiUrl;
    qrCode.alt = 'QR Code';
    qrCodeContainer.appendChild(qrCode);
});
